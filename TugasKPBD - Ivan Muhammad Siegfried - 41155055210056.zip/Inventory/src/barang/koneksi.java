/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package barang;
// Proses Import Package yang Dibutuhkan 
import java.sql.DriverManager;
import javax.swing.*; 
import java.awt.*; 
import java.awt.event.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


/**
 *
 * @author ivanm
 */
public class koneksi {
    private static java.sql.Connection koneksi;
    
    public static java.sql.Connection getKoneksi(){
        if (koneksi == null){
            try{
                // Parameter Untuk MySQL
                String url = "jdbc:mysql://localhost:3306/crudmysql"; 
                String user = "root";
                String password = "";
                
                // Registrasi Driver dan Instalasi Koneksi 
                DriverManager.registerDriver(new com.mysql.jdbc.Driver());
                koneksi = DriverManager.getConnection(url, user, password);
                System.out.println("Berhasil Terhubung");
            } catch (Exception e){
                System.out.println("Error");
            }
        }
        return koneksi;
    }
    
    public static void main(String args[]){
        
        // Fungsi Utama Menghubungkan Koneksi
        getKoneksi();
    }
}
